import requests

url = "http://ipv4.download.thinkbroadband.com/20MB.zip"
r = requests.get(url)


